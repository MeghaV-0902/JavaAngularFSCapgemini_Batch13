package com.cg.onlineadmissionsystem.Repository;

import com.cg.onlineadmissionsystem.Model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role,Integer>
{

}
